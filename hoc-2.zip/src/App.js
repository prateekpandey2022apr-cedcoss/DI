import logo from "./logo.svg";
import "./App.css";
import { useEffect, useState } from "react";
import List from "./List";

function App() {
  const [loading, setIsLoading] = useState(false);
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    setIsLoading(true);
    fetch("https://jsonplaceholder.typicode.com/todos")
      .then((response) => response.json())
      .then((response) => {
        // console.log(response);
        setTodos(response);
        setIsLoading(false);
      });
  }, []);

  return <List loading={loading} todos={todos} />;
}

export default App;
